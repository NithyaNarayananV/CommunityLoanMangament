import { LightningElement } from 'lwc';

export default class P2cAlertComponent extends LightningElement {}